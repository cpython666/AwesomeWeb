# Curzr | Free cursor library

A Pen created on CodePen.io. Original URL: [https://codepen.io/tin-fung-hk/pen/PoRWVRg](https://codepen.io/tin-fung-hk/pen/PoRWVRg).

Curzr | Free cursor library

https://curzr.profyr.com/

There's a range of cursors which is totally free. Each cursor is unique and has its own behaviour for you to explore. Furthermore, they are customisable with the live preview. It is supported by all browsers, try to copy and paste it into your creative project now!